  
//Q1

//CREATING REQUIRED TABLES
CREATE TABLE Instructor ( 

    ins_ID int PRIMARY KEY NOT NULL, 

    ins_fname varchar(255) NOT NULL, 

   ins_sname varchar(255) NOT NULL, 

   ins_contact varchar(255) NOT NULL,
    ins_level int NOT NULL
); 
		 		
  

CREATE TABLE Customer ( 

    cust_id  varchar(255) PRIMARY KEY NOT NULL, 

   cust_fname varchar(255) NOT NULL, 

    cust_sname varchar(255) NOT NULL, 

   cust_address varchar(255) NOT NULL, 

   	cust_contact
    int NOT NULL 

); 


CREATE TABLE Dive ( 

   DIVE_ID  int PRIMARY KEY NOT NULL, 
   DIVE_NAME varchar(255) NOT NULL,
   DIVE_DURATION varchar(255) NOT NULL,
   DIVE_LOCATION varchar(255) NOT NULL,
   DIVE_EXP_LEVEL int NOT NULL,
   DIVE_COST  varchar(255)NOT NULL 

); 


 
CREATE TABLE Dive_Event (
    dive_event_id varchar(255) PRIMARY KEY NOT NULL,
    dive_date DATE NOT NULL,
    dive_participants int NOT NULL,
    ins_ID  int NOT NULL,
    cust_id varchar(255) NOT NULL,
    DIVE_ID int NOT NULL,
    FOREIGN KEY (ins_ID ) REFERENCES Instructor(ins_ID ),
    FOREIGN KEY (cust_id) REFERENCES Customer(cust_id),
    FOREIGN KEY (DIVE_ID) REFERENCES Dive(DIVE_ID)
);

//POPULATING REQUIRED TABLES
INSERT INTO Instructor(ins_ID,ins_fname,	ins_sname ,	ins_contact,	ins_level )
VALUES (101,	'James','Willis',0843569851,	7);
INSERT INTO Instructor(ins_ID,ins_fname,	ins_sname ,	ins_contact,	ins_level )
VALUES (102,	'Sam','	Wait',	0763698521,	2);
INSERT INTO Instructor(ins_ID,ins_fname,	ins_sname ,	ins_contact,	ins_level )
VALUES (103,	'Sally','	Gumede',	0786598521,	8);
INSERT INTO Instructor(ins_ID,ins_fname,	ins_sname ,	ins_contact,	ins_level )
VALUES (104,'Bob','	Du Preez',	0796369857,	3);
INSERT INTO Instructor(ins_ID,ins_fname,	ins_sname ,	ins_contact,	ins_level )
VALUES (105,'Simon','	Jones',	0826598741,	9);

 				 	

INSERT INTO customer(cust_id 	,cust_fname 	,cust_sname	,cust_address 	,cust_contact) 
VALUES ('C115', 'Heinrich', 'Willis', '3 Main Road', '0821253659');

INSERT INTO customer(cust_id 	,cust_fname 	,cust_sname	,cust_address 	,cust_contact)  
VALUES ('C116', 'David', 'Watson', '13 Cape Road', '0769658547');
INSERT INTO customer(cust_id 	,cust_fname 	,cust_sname	,cust_address 	,cust_contact)  
VALUES ('C117', 'Waldo', 'Smith', '3 Mountain Road', '0863256574');

INSERT INTO customer(cust_id 	,cust_fname 	,cust_sname	,cust_address 	,cust_contact)  
VALUES ('C118', 'Alex', 'Hanson', '8 Circle Road', '0762356587');

INSERT INTO customer(cust_id 	,cust_fname 	,cust_sname	,cust_address 	,cust_contact) 
VALUES ('C119', 'Kuhle', 'Bitterhout', '15 Main Road', '0821235258');

INSERT INTO customer(cust_id 	,cust_fname 	,cust_sname	,cust_address 	,cust_contact) 
VALUES ('C120', 'Thando', 'Zolani', '88 Summer Road', '0847541254');

INSERT INTO customer(cust_id 	,cust_fname 	,cust_sname	,cust_address 	,cust_contact)  
VALUES ('C121', 'Philip', 'Jackson', '3 Long Road', '0745556658');

INSERT INTO customer(cust_id 	,cust_fname 	,cust_sname	,cust_address 	,cust_contact) 
VALUES ('C122', 'Sarah', 'Jones', '7 Sea Road', '0814745745');

INSERT INTO customer(cust_id 	,cust_fname 	,cust_sname	,cust_address 	,cust_contact) 
VALUES ('C123', 'Catherine', 'Howard', '31 Lake Side Road', '0822232521');



INSERT INTO Dive(DIVE_ID, DIVE_NAME, DIVE_DURATION, DIVE_LOCATION, DIVE_EXP_LEVEL, DIVE_COST) 
VALUES (550, 'Shark Dive ', '3 hours ', 'Shark Point ', 8, '500')

 INSERT INTO Dive(DIVE_ID, DIVE_NAME, DIVE_DURATION, DIVE_LOCATION, DIVE_EXP_LEVEL, DIVE_COST) 
VALUES (551, 'Coral Dive ', '1 hour ', 'Break Point ', 7, 300);

INSERT INTO Dive(DIVE_ID, DIVE_NAME, DIVE_DURATION, DIVE_LOCATION, DIVE_EXP_LEVEL, DIVE_COST) 
VALUES (552, 'Wave ', '2 hours ', 'Ship wreck ally ', 3, 800);

INSERT INTO Dive(DIVE_ID, DIVE_NAME, DIVE_DURATION, DIVE_LOCATION, DIVE_EXP_LEVEL, DIVE_COST) 
VALUES (NULL, 'Crescent ', NULL, NULL, NULL, NULL);

INSERT INTO Dive(DIVE_ID, DIVE_NAME, DIVE_DURATION, DIVE_LOCATION, DIVE_EXP_LEVEL, DIVE_COST) 
VALUES (553, 'Underwater ', '1 hour ', 'Coral ally ', 2, 250);

INSERT INTO Dive(DIVE_ID, DIVE_NAME, DIVE_DURATION, DIVE_LOCATION, DIVE_EXP_LEVEL, DIVE_COST) 
VALUES (NULL, 'Exploration ', NULL, NULL, NULL, NULL);

INSERT INTO Dive(DIVE_ID, DIVE_NAME, DIVE_DURATION, DIVE_LOCATION, DIVE_EXP_LEVEL, DIVE_COST)  
VALUES (554, 'Underwater ', '3 hours ', 'Sandy Beach ', 3, 750);

INSERT INTO Dive(DIVE_ID, DIVE_NAME, DIVE_DURATION, DIVE_LOCATION, DIVE_EXP_LEVEL, DIVE_COST) 
VALUES (NULL, 'Adventure ', NULL, NULL, NULL, NULL);

INSERT INTO Dive(DIVE_ID, DIVE_NAME, DIVE_DURATION, DIVE_LOCATION, DIVE_EXP_LEVEL, DIVE_COST) 
VALUES (555, 'Deep Blue ', '30 minutes ', 'Lazy Waves ', 2, 120);

INSERT INTO Dive(DIVE_ID, DIVE_NAME, DIVE_DURATION, DIVE_LOCATION, DIVE_EXP_LEVEL, DIVE_COST) 
VALUES (NULL, 'Ocean ', NULL, NULL, NULL, NULL);
INSERT INTO Dive(DIVE_ID, DIVE_NAME, DIVE_DURATION, DIVE_LOCATION, DIVE_EXP_LEVEL, DIVE_COST) ) 
VALUES (556, 'Rough Seas ', '1 hour ', 'Pipe ', 9, 700);

INSERT INTO Dive(DIVE_ID, DIVE_NAME, DIVE_DURATION, DIVE_LOCATION, DIVE_EXP_LEVEL, DIVE_COST) 
VALUES (557, 'White Water ', '2 hours ', 'Drifts ', 5, 200);

INSERT INTO Dive(DIVE_ID, DIVE_NAME, DIVE_DURATION, DIVE_LOCATION, DIVE_EXP_LEVEL, DIVE_COST) 
VALUES (558, 'Current ', '2 hours ', 'Rock Lands ', 3, 150);



INSERT INTO Dive_Event (DIVE_EVENT_ID, DIVE_DATE, DIVE_PARTICIPANTS, INS_ID, CUST_ID, DIVE_ID) 
VALUES ('de_101', to_date('15-Jul-17', 'DD-MON-RR'), 5, 103, 'C115', 558);


INSERT INTO Dive_Event (DIVE_EVENT_ID, DIVE_DATE, DIVE_PARTICIPANTS, INS_ID, CUST_ID, DIVE_ID) 
VALUES ('de_102', to_date('16-Jul-17', 'DD-MON-RR'), 7, 102, 'C117', 555);


INSERT INTO Dive_Event (DIVE_EVENT_ID, DIVE_DATE, DIVE_PARTICIPANTS, INS_ID, CUST_ID, DIVE_ID)  
VALUES ('de_103', to_date('18-Jul-17', 'DD-MON-RR'), 8, 104, 'C118', 552);

INSERT INTO Dive_Event (DIVE_EVENT_ID, DIVE_DATE, DIVE_PARTICIPANTS, INS_ID, CUST_ID, DIVE_ID) 
VALUES ('de_104', to_date('19-Jul-17', 'DD-MON-RR'), 3, 101, 'C119', 551);

INSERT INTO Dive_Event (DIVE_EVENT_ID, DIVE_DATE, DIVE_PARTICIPANTS, INS_ID, CUST_ID, DIVE_ID) 
VALUES ('de_105', to_date('21-Jul-17', 'DD-MON-RR'), 5, 104, 'C121', 558);


INSERT INTO Dive_Event (DIVE_EVENT_ID, DIVE_DATE, DIVE_PARTICIPANTS, INS_ID, CUST_ID, DIVE_ID)  
VALUES ('de_106', to_date('22-Jul-17', 'DD-MON-RR'), 8, 105, 'C120', 556);


INSERT INTO Dive_Event (DIVE_EVENT_ID, DIVE_DATE, DIVE_PARTICIPANTS, INS_ID, CUST_ID, DIVE_ID)  
VALUES ('de_107', to_date('25-Jul-17', 'DD-MON-RR'), 10, 105, 'C115', 554);


INSERT INTO Dive_Event (DIVE_EVENT_ID, DIVE_DATE, DIVE_PARTICIPANTS, INS_ID, CUST_ID, DIVE_ID)  
VALUES ('de_108', to_date('27-Jul-17', 'DD-MON-RR'), 5, 101, 'C122', 552);


INSERT INTO Dive_Event (DIVE_EVENT_ID, DIVE_DATE, DIVE_PARTICIPANTS, INS_ID, CUST_ID, DIVE_ID) 
VALUES ('de_109', to_date('28-Jul-17', 'DD-MON-RR'), 3, 102, 'C123', 553);
SELECT *FROM CUSTOMER;

//q2
//ADMIN ROLE HAS FULL PRIVELEDGES DUE TO RESPONSIBILITIES ASSCOSCIATED WITH ROLE,The monitoring of how a database performs.

GRANT USER C##Dive_Admin IDENTIFIED BY diveadmindb2023;
GRANT CONNECT TO C##Dive_Admin;


//GENERAL WITH LIMITED ROLES
GRANT CREATE SESSION TO C##Dive_Admin;
GRANT SELECT ANY TABLE TO C##Dive_Admin;
GRANT USER C##Mya IDENTIFIED BY mrrobertabc2023;


//GRANT ONLY INSERT ON SOME TABLES AND VIEWS DUE TO FUNCTIONALITY OF SYSTEM
//UPDATE SPECIFIC TABLES
//OUR USER WILL BE MYA
GRANT INSERT,UPDATE ON CUSTOMER,DIVE_event to db_dive_user;
GRANT CONNECT TO C##Mya;

GRANT CREATE SESSION TO C##Mya;
GRANT SELECT ANY TABLE TO C##Mya



//q3


SELECT ins_fname |''|i. ins_sname AS 
instructor
cust_fname |''|i. cust_sname AS 
customer
d.dive_participants as participants
d.dive_loaction as location
FROM
dive_events d
LEFT JOIN instructors
JOIN REPAIRSpg r ON d.ins_id = i.ins_id;

JOIN REPAIRSpg r ON d.ins_id = i.ins_id;
WHERE participants BETWEEN 8 AND 10;



//q4


SELECT ins_fname |''|i. ins_sname AS 
instructor
cust_fname |''|i. cust_sname AS 
customer
d.dive_participants as participants
d.dive_loaction as location
FROM
dive_events d
LEFT JOIN instructors
JOIN REPAIRSpg r ON d.ins_id = i.ins_id;

JOIN REPAIRSpg r ON d.ins_id = i.ins_id;
WHERE participants BETWEEN 8 AND 10;

//q5
//CREATING QUERY OF INSTRUCTORS REQUIRED
SET SERVEROUTPUT ON; 

DECLARE  

    CURSOR dive_report IS
    SELECT c.cust_fname||''||c.cust_sname AS customer_name,d.dive_name,
    d.dive_participants,
    CASE
    WHEN d.dive_participants<=4 then 1
    WHEN d.dive_participants 7<5 THEN 2
    ELSE 3
    END AS Instructors_required
    FROM CUSTOMERS C
    JOIN dive_events d on c.customer_id=d.customer_id
    where d.dive_cost>500;
    
    
    v_customer_name varchar(255);
    v_dive_name varchar(255);
    v_participants number;
    v_instructors_required number;
     

 
    
    BEGIN
    OPEN dive_report;
    LOOP
    FETCH dive_report INTO v_customer_name,
    v_dive_name,v_participants,
    v_instructors_required
    EXIT WHEN dive_report%NOTFOUND;
    DBMS_OUTPUTPUT_LINE(
    'CUSTOMER:'||v_customer_name||
    'DIVE NAME:'||v_dive_name||
    'PARTICIPANTS:'||v_participants
    'STATUS:'||v_CUSTOMER_NAME.INSTRUCTORS_REQUIRED
    ||'INSTRUCTORS REQUIRED.'
    );
    END LOOP;
    CLOSE dive_report;
    end;
    
    
 
	
//q6

//creating view
CREATE VIEW Vw_Dive_Event AS 

SELECT i.ins_id,

       c.cust_id,
       rc.cust_address,
       d.dive_duration,
       d.dive_date

FROM CUSTOMER C

JOIN CUSTOMER c ON sl.CUST_ID = c.CUST_ID 

JOIN STOCKpg st ON sl.STOCK_ID = st.STOCK_ID 

JOIN REPAIRSpg r ON sl.REPAIR_ID = r.REPAIR_ID; 

  

SELECT * FROM Repair_View; 
	 
//Q7
//creating trigger to disrupt these errors and prevent them

CREATE OR REPLACE TRIGGER new_dive_event
BEFORE INSERT OR UPDATE on dive_event
FOR EACH ROW
BEGIN
IF :NEW.dive_participants >20 THEN
RAISE_APPLICATION_ERROR(-20000, 'participants must not be more than 20');
END IF;
IF:
IF :NEW.dive_participants >1 THEN
RAISE_APPLICATION_ERROR(-20000, 'participants must be equal to zero');
END IF;
END;
 
INSERT INTO dive_event (DIVE_EVENT_ID, DIVE_DATE, DIVE_PARTICIPANTS, INS_ID, CUST_ID, DIVE_ID)  
VALUES();


//Q8
//CREATE PROCEDURE
CREATE PROCEDURE sp_Customer_Details(
p_customer_id NUMBER,
p_dive\_id NUMBER

)
AS
BEGIN
DECLARE 
v_customer_name varchar(255);
    v_dive_name varchar(255);
    
    BEGIN
    SELECT c.CUST_FNAME
      SELECT c.cust_fname||''||c.cust_sname AS v_customer_name,d.dive_name,
into  v_customer_name,v.dive_name,
FROM CUSTOMERS C

JOIN D dive_nameJOIN dive_events d on c.customer_id=d.customer_id
   c.customer_id=p_customer_id;
   
   DBMS_OUTPUTPUT_LINE(
    'CUSTOMER details:'||v_customer_name||
    'booked for the:'||v_dive_name||
    
    );
    
    PERCEPTION WHEN NO_DATA_FOUND THEN 
    
     DBMS_OUTPUTPUT_LINE('NO CUSTMER FOUND');
     END;
     
     //ERROR HANDLING
     BEGIN
     sp_CUSTOMER_DEATILS(1,1)
     EXCEPTION
     WHEN OTHERS THEN
     BMS_OUTPUTPUT_LINE('ERROR');
     END;
     
//Q9

//CREATE CALCULATE DIVE COST FUNCTION

CREATE FUNCTION calculate_dive_cost(
participants NUMBER;
dive_cost_per_participant NUMBER 
)
RETURN NUMBER AS
BEGIN
IF participants <=0 THEN
RAISE_APPLICATION_ERROR(-20002,'MUST BE MORE THAN 0.');
END IF;
RETURN PARTICIPANTS *dive_cost_per_participant
exception 
when others then
raise;
end;
select calculate_dive_cost(10,50) AS TOTAL_DIVE_COST
FROM DUAL;

